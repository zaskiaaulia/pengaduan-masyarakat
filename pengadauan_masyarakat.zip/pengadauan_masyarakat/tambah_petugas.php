<form method="post" action="proses_tambah_petugas.php" class="user">
                    <div class="form-group">
                      <input name="id_petugas" type="text" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Masukan id_peugas yang ingin dibuat.....">
                    </div>
                    <div class="form-group">
                      <input name="nama_petugas" type="text" class="form-control form-control-user" id="exampleInputPassword" placeholder="masukan nama_petugas">
                    </div>
                    <div class="form-group">
                      <input name="username" type="text" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="masukan username petugas">
                    </div>
                    <div class="form-group">
                      <input name="kata_sandi" type="text" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Masukan password yang petugas">
                    </div>
                    <div class="form-group">
                      <input name="telp" type="text" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="masukan nomor telpon petugas">
                    </div>
                    <button type="submit" a href="proses_tambah_petugas.php" class="btn btn-primary btn-user btn-block">
                      tambahkan
                    </button>